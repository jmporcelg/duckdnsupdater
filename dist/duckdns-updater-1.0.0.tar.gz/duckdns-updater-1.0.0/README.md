# duckdnsupdater
Tkinter simple DuckDNS IP updater 
