from setuptools import setup, find_packages

setup(
    name="duckdns-updater",
    version="1.0.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "requests",
        "pystray",
        "Pillow",
    ],
    entry_points={
        "console_scripts": [
            "duckdns-updater = duckdns_updater.__init__:main",
        ],
    },
    author="Jose Porcel",
    description="DuckDNS IP Updater",
    long_description="A DuckDNS IP updater application.",
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
)
